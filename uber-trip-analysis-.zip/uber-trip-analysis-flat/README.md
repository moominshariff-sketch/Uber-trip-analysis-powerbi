# Uber Trip Analysis | Power BI Dashboard

An interactive three-page Power BI report analyzing **103,728 Uber trips from June 2024** ($1.55M booking value) across bookings, revenue, trip efficiency, locations and time patterns.

## Dashboard Preview
| Overview Analysis | Time Analysis | Details (drill-through) |
|---|---|---|
| ![Overview](01-overview.png) | ![Time](02-time-analysis.png) | ![Details](03-details.png) |

## Objective
Give stakeholders one place to see:
- how many trips are booked, how much revenue they bring, and how efficient trips are (distance and duration)
- which vehicle types and payment methods drive the business
- where demand is concentrated (top pickup and drop-off zones)
- when demand peaks, by hour, day of week and day vs. night

Full requirements: [Business_Requirement.docx](Business_Requirement.docx)

## Dataset
| File | Description |
|---|---|
| `Uber_Trip_Details.xlsx` | 103,728 trips: pickup and drop-off time, distance, fare, surge fee, vehicle, payment type, passenger count, location IDs |
| `Location_Table.xlsx` | 265 NYC zones with borough/city |

## Tools and Techniques
**Tools:** Power BI Desktop, DAX, Power Query, Excel

**Data model**
- Star-style model: `Trip Details` (fact) and `Location Table` (dimension)
- Two relationships between them: pickup (active) and drop-off (inactive)
- DAX-generated `Calendar Table` for the date slicer and day names

**DAX highlights**
- Core measures: Total Bookings, Total Booking Value (fare + surge fee), Avg Booking Value (`DIVIDE`), Total and Avg Trip Distance, Avg Trip Time (`AVERAGEX` + `DATEDIFF`)
- `USERELATIONSHIP` to activate the inactive drop-off relationship for Most Frequent Drop-off Point
- `TOPN` + `SUMMARIZE` for Most Frequent Pickup Point; `LOOKUPVALUE` for Farthest Trip
- Disconnected table with `NAMEOF` and a dynamic measure selector (Bookings / Value / Distance), with dynamic titles via `SELECTEDVALUE`
- Calculated columns: Day/Night flag (day = 6:00 to 17:00), pickup hour, 10-minute pickup bins

**Visuals and interactivity:** KPI cards, donut charts, area and bar charts, a vehicle table with data bars, an hour × day heatmap with conditional formatting, slicers (date, city), page navigation, and drill-through to trip-level details.

## Key Findings
- **Scale:** average booking $15, average trip 3.4 miles and 16 minutes. Surge fees are about 13% of booking value and 64% of trips carry one.
- **Payments:** Uber Pay 67%, cash 32%, wallets under 1%. Cash trips average $13.26 vs. $15.81 for Uber Pay.
- **Day vs. night:** 65% day trips, 35% night trips.
- **Vehicles:** UberX has 38.7K bookings (37%) and $584K in value. Average fare and trip length are nearly identical across vehicle types.
- **Locations:** top pickup is Penn Station/Madison Sq West (4,475); top drop-off is Upper East Side North (4,024). Farthest trip: 144.1 miles.
- **Time of day:** lowest at 3 to 4 AM, peak around 3 PM (about 7.9K trips an hour).
- **Day of week:** weekend totals look highest only because June 2024 has five Saturdays and five Sundays. Per day, Wednesday leads (about 3.9K) and weekends are 3.7K to 3.8K. **Thursday (2.8K) and Friday (2.3K) are the weakest.**

## Insights and Recommendations
1. Plan driver supply around 12 to 6 PM and the Upper East Side, Penn Station and Lenox Hill zones.
2. UberX is the volume driver; vehicle tiers differ in volume, not in fare or distance.
3. Cash is a third of trips with the lowest average value, so digital-payment incentives are a growth lever.
4. Test promotions on Thursdays and Fridays.

## Limitations
- One month of data, so seasonality can't be assessed.
- 13,196 Trip IDs are missing from the sequence, so the Thursday/Friday dip should be confirmed before acting on it.
- Average trip time (16 min) is pulled up by 235 trips over 3 hours; the median is 10.7 minutes.
- Power Query only sets data types; no outlier handling was applied.

## How to Open
1. Download `Uber_Trip_Analysis.pbix` and open it in Power BI Desktop.
2. If prompted, point the two data sources to `Uber_Trip_Details.xlsx` and `Location_Table.xlsx` (Home → Transform data → Data source settings → Change Source).

## Author
**Momin**: B.Com graduate transitioning into data analytics. Skills: SQL, Python, Power BI, Excel.
